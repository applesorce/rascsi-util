#!/bin/sh
sudo rascsi -ID1 BRIDGE
