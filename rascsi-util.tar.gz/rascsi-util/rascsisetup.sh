CSI環境を構築スクリプト
#systemdに登録までしてしまうのです
#登録されるsystemd等はread.meで確認すること
#
#。
wget http://www.geocities.jp/kugimoto0715/rascsi/rascsi120.zip
unzip rascsi120.zip
mv rascsi120/bin/raspberrypi/rascsi.tar.gz  .
tar zxvf rascsi.tar.gz
sudo mv rascsi /usr/local/bin/
sudo mv rasctl /usr/local/bin/
echo "後片付けを行います。"
sleep 1
rm rascsi120.zip
rm -rf rascsi120/
rm rascsi.tar.gz
echo -n "/usr/local/binへのrascsiのインストールが行われました。デーモン登録(HDD,bridge,allどれか)を実施しますか？[h/e/a/n]"
while :
  do
    read INPUT
    case "$INPUT" in
      "h" ) sudo mv rascsihdd.sh /usr/local/bin/

sudo cat << eof > sudo ls -la /etc/systemd/system/rascsihdd.service

[Unit]
Description = raScsiHddDaemon
[Service]
ExecStart=/usr/local/bin/rascsihdd.sh
ExecReload=/bin/kill -HUP $MAINPID
ExecStop=/bin/kill $MAINPID
Restart=no
Type=simple

[Install]
WantedBy = multi-user.target
EOF
sudo chown root:root /etc/systemd/system/rascsihdd.service
sudo systemctl enable rascsihdd.service
sudo systemctl enable rascsihdd
sudo systemctl start rascsihdd
            
            break ;;
      "e" ) sudo mv rascsibrid.sh /usr/local/bin/
            
sudo cat << eof > sudo ls -la /etc/systemd/system/rascsibrid.service

[Unit]
Description = raScsiBridgeDaemon
[Service]
ExecStart=/usr/local/bin/rascsibrid.sh
ExecReload=/bin/kill -HUP $MAINPID
ExecStop=/bin/kill $MAINPID
Restart=no
Type=simple

[Install]
WantedBy = multi-user.target
EOF
sudo chown root:root /etc/systemd/system/rascsibrid.service
sudo systemctl enable rascsibrid.service
sudo systemctl start rascsibrid
            
            break ;;

      "a" ) sudo mv rascsiall.sh /usr/local/bin/
            
sudo cat << eof > sudo ls -la /etc/systemd/system/rascsiall.service

[Unit]
Description = raScsiallDaemon
[Service]
ExecStart=/usr/local/bin/rascsiall.sh
ExecReload=/bin/kill -HUP $MAINPID
ExecStop=/bin/kill $MAINPID
Restart=no
Type=simple

[Install]
WantedBy = multi-user.target
EOF
sudo chown root:root /etc/systemd/system/rascsiall.service
sudo systemctl enable rascsiall.service
sudo systemctl start rascsiall
            
            break ;;


      "n" ) echo "Canceled."
            break ;;
      * )   echo "ちゃんと入力してね！" ;;
    esac
  done
  


