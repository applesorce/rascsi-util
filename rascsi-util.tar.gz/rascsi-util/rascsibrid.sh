#!/bin/sh
#IDは適時変更すること
sudo rascsi -ID1 BRIDGE
